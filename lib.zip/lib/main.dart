import 'package:admin_panel/config/app.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}