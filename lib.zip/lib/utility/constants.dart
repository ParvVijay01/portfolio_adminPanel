import 'package:flutter/material.dart';

const primaryColor = Color(0xFF3674B5);
const secondaryColor = Color(0xFF578FCA);
const bgColor = Color(0xFFA1E3F9);
const defaultPadding = 16.0;

const MAIN_URL = 'http://localhost:5000';
